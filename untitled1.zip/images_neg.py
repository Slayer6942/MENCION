from PIL import Image
import random
imagen = Image.open("images/Imagen_1.jpg")

dimX = [50,100,150,200,250]
dinY = [50,100,150]

arch = open("entrenamiento/negativas/negativas.txt","w")
cont = 0

arch = open("negativas.txt","w")

while cont <= 1000:
    RDX = dimX[random.randint(0,4)]
    RDY = dimX[random.randint(0,2)]
    x = random.randint(0,imagen.size[0]-RDX)
    y = random.randint(0,imagen.size[1]-RDY)

    caja = (x,y,x+RDX,y+RDY)

    region = imagen.crop(caja)

    region.save("entrenamiento/negativas/"+str(cont)+".jpg")
    arch.write("negativas/"+str(cont)+".jpg")
    cont+=1
arch.close()