from PIL import Image, ImageDraw
from lxml import etree

def comprobar(x1,y1,x2,y2):
    X1=x1
    Y1=y1
    X2=x2
    Y2=y2
    if x1 > x2:
        X1 = x2
        X2= x1
    if y1 > y2:
        Y1 = y2
        Y2 = y1
    return X1,Y1,X2,Y2

arch = open("entrenamiento/positivas/positivas.txt","w")

x = 1
while x <= 12:
    imagen = Image.open("images/Imagen_"+str(x)+".jpg")
    #imagen.show()
    #imagen = ImageDraw.rectangle([(x0, y0),(x1, y1)], fill=None, outline=None)
    doc = etree.parse('images/imagen_'+str(x)+'.xml')
    cont =1
    raiz=doc.getroot()
    for i in range(4,len(raiz),1):
        t1 = raiz[i]
        #print t1[7].text
        t2 = t1[9]
        p1 = t2[1]
        p2 = t2[2]
        p3 = t2[3]
        p4 = t2[4]
        X1 = int(p1[0].text)
        Y1 = int(p1[1].text)
        X2 = int(p2[0].text)
        Y2 = int(p2[1].text)
        X3 = int(p3[0].text)
        Y3 = int(p3[1].text)
        X4 = int(p4[0].text)
        Y4 = int(p4[1].text)
        dibujo = ImageDraw.Draw(imagen)
        px1, py1,px2,py2 = comprobar(X1,Y1,X2,Y3)
        if px1 < px2:
            dimX = px2 - px1
        else:
            dimX = px1 - px2
        if py1 < py2:
            dimY = py2 - py1
        else:
            dimY = py1 - py2
        print px1,py1,dimX,dimY
        region = imagen.crop((px1,py1,px2,py2))
        region.save("entrenamiento/positivas/"+str(x)+"_"+str(cont)+".jpg")
        #dibujo.point((int(X2), int(Y2)), (255, 0, 0))
        #arch.write(str(x)+"_"+str(cont) + ".jpg "+ str(px1)+" "+str(py1)+" "+str(dimX)+" "+str(dimY)+"\n")
        arch.write("..\..\images\Imagen_"+str(x)+".jpg 1 "+ str(px1)+" "+str(py1)+" "+str(dimX)+" "+str(dimY)+"\n")
        cont += 1
    x+= 1
    #imagen.save("pruebas/cosa.jpg")